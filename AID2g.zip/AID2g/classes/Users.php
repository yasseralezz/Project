<?php 

  class Users { 

  // define properties /attributes 

  private $userID; 
  private $password; 
  private $email; 
  private $protection;
  private $isAdmin;

  //Constructor called when instantiating bear. This demonstrates a default weight parameter

  public function __construct(){ 

  } 

  //Destructor called when object leaves scope or script terminates 

  public function __destruct(){ 

  } 

  //Setters 
  public function setUserID($userID) { 
	$this->userID = $userID;
  } 
  
  public function setPassword($password) {
	$this->password = $password;
  }
  
  public function setEmail($email) {
	$this->email = $email;
  }
  
  public function setProtection($protection) {
	$this->protection = $protection;
  }
  
  public function setIsAdmin($isAdmin) {
	$this->isAdmin = $isAdmin;
  }
  
  //Getters
  public function getUserID() { 
	return $this->userID; 
  } 
  
  public function getPassword() {
	return $this->password;
  }
  
  public function getEmail() {
	return $this->email;
  }
  
  public function getProtection() {
	return $this->protection;
  }
  
  public function getIsAdmin() {
	return $this->isAdmin;
  }
  
}
?>