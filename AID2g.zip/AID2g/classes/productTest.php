<?php 
require_once('Products.php'); 

  //Instantiate first product -  name to constructor 

  $product = new Products(); 
  $product->setProductID("1</p><br/>"); 
  $product->setName("Nivida</p><br/>");
  $product->setPrice("99.99</p><br/>");
  $product->setQuantity("69</p><br/>");
  $product->setImageName("image1.jpg</p><br/>");
  
  
  print "<span>Products Created</span><br/>";
  print "<p>Product ID: ".$product->getProductID();
  print "<p>Product Name: ".$product->getName();
  print "<p>Product Price: ".$product->getPrice();
  print "<p>Product Quantity: ".$product->getQuantity();
  print "<p>Product Image Name: ".$product->getImageName();
  


//Exiting will invoke the destructors 
  $product->__destruct(); 
?>