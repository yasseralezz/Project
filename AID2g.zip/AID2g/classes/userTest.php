<?php 
require_once('Users.php'); 

  //Instantiatefirst product - oass name to constructor 

  $user = new Users(); 
  $user->setUserID("yasser"); 
  $user->setPassword("pwd123");
  $user->setEmail("yasser_on@hotmail.com");

  print "<span>Users Created </span>";
  print "<br/>Username = ".$user->getUserID();
  print "<br/>Password = ".$user->getPassword();
  print "<br/>Email = ".$user->getEmail();



//Exiting will invoke the destructors 

  $user->__destruct(); 
?>