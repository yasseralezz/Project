<?php
include '../config/config3.php';

class Database_connect{
	function __construct(){
		$this->connection = mysql_connect(DBHOST,DBUSER,DBPASS,DBNAME);
		mysql_select_db(DBNAME,$this->connection) or die (mysql_error());
	}
	function disconnect(){
		mysql_close($this->connection);
	}
}

class shoppingCart{
	function writeShoppingCart(){
		$cart = $_SESSION['cart'];
		if(!$cart){
			return '0 Items';
		} else { 
		$items = explode (',',$cart);
		$number = (count($items) >1) ? '' : '';
		return ''.count($items).'Items'.$number.'</td>';
	}
}

	function showCart(){
		$database = new Database_connect();
		$cart = $_SESSION['cart'];
		if($cart){
			$items = explode (',',$cart);
			$contents = array();
			foreach ($items as $item){
				$contents[$item] = (isset($contents[$item])) ? $contents[$item]+1 : 1;
			}
			$output[] = '<form action="cart.php?action=update" method="POST" id="cart"';
			foreach ($contents as $id=>$qty){
				$sql = 'SELECT * FROM products WHERE productID = '.$id;
				$result = mysql_query($sql);
				$user_data = mysql_fetch_array($result);
				extract($user_data);
				$output[] = '<tr><td><img src="../product/images/'.$imageName.'" width="150" height="150" alt="'.$name.'" /></td>';
				$output[] = '<td>'.$name.'</td>';
				$output[] = '<td>'.$price.'</td>';
				$output[] = '<td><input type="text" name="quantity'.$id.'" value='.$qty.' size="3" maxlength="3" /></td>';
				$totalCost += $price * $qty;
				$output[] = '<td>$'.($price * $qty).'</td>';
				$output[] = '<td><a href="cart.php?action=delete&productID='.$id.'" ><input type="button" value="Remove"></a></td>';
				

				}
				$output[] = '</tr> </tbody> </table> <br/>';
				$output[] = '<h1> Total : <strong>$'.$totalCost.'</strong></h1>';
				$output[] = '<input type="submit" value="Update">';
				$output[] = '</form>';
				$output[] = '<br/><a href="../index.php"><input type="submit" value="Add more!"></a>';

			}
			else {
			$output[] = '<h2> Your Cart is Empty. <a href="../index.php">Back</a> to products!</h2><br/><br/></tbody></table></div></div>';
		}
	return join('',$output);
	}
}
?>