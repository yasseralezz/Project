<?php
ob_start();
error_reporting(E_ALL & ~E_NOTICE);
?>
<!DOCTYPE HTML>
<head>
<title> Facebook Graph API | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

<link href="style.css" rel="stylesheet" type="text/css" media="all"/>
</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo3(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Author facebook feed </li>
						<div class="clear"> </div>
				</ul>

<?php
    // include the facebook sdk
    require_once('facebook.php');

    // connect to app
    $config = array();
    $config['appId'] = '1514180815557537';
    $config['secret'] = 'a7fcab170733380e3065a34bf8bcc7ea';
    $config['fileUpload'] = true; // optional

    // instantiate
    $facebook = new Facebook($config);

    // set page id
    $pageid = "1103462293028740";

    // now we can access various parts of the graph, starting with the feed
    $pagefeed = $facebook->api("/" . $pageid . "/feed");
    $pagefeed = $facebook->api("/" . $pageid . "/feed?fields=type,message,id,story,link");
?>

<?php
echo "<div class=\"fb-feed\">";
	
// set counter to 0, because we only want to display 10 posts
$i = 0;
	foreach($pagefeed['data'] as $post) { 
			if ($post['type'] == 'status' || $post['type'] == 'link' || $post['type'] == 'photo') {

				// open up an fb-update div
				echo "<div class=\"fb-update\">";  
				
                // post the time
                // check if post type is a status
                if ($post['type'] == 'status') {
                    echo "<h2>Status updated: " . date("jS M, Y", (strtotime($post['created_time']))) . "</h2>";
                    if (empty($post['story']) === false) {
                        echo "<p>" . $post['story'] . "</p>";
                        } elseif (empty($post['message']) === false) {
						echo "<p>" . $post['message'] . "</p>";
                    }
                }
                        
                // check if post type is a link
                if ($post['type'] == 'link') {
                    echo "<h2>Link posted on: " . date("jS M, Y", (strtotime($post['created_time']))) . "</h2>";
                    echo "<p>" . $post['name'] . "</p>";
                    echo "<p><a href=\"" . $post['link'] . "\" target=\"_blank\">" . $post['link'] . "</a></p>";
                }
                        
                // check if post type is a photo
                if ($post['type'] == 'photo') {
                    echo "<h2>Photo posted on: " . date("jS M, Y", (strtotime($post['created_time']))) . "</h2>";
                    if (empty($post['story']) === false) {
                        echo "<p>" . $post['story'] . "</p>";
                    } elseif (empty($post['message']) === false) {
                        echo "<p>" . $post['message'] . "</p>";
                    }
                    echo "<p><a href=\"" . $post['link'] . "\" target=\"_blank\">View photo &rarr;</a></p>";
                }

				echo "</div>"; // close fb-update div
                    
                $i++; // add 1 to the counter if our condition for $post['type'] is met
            } 
            //  break out of the loop if counter has reached 10
            if ($i == 10) {
                break;
            }
	} // end the foreach statement
            
	echo "</div>";
?>
	</div>
<div class="clear"></div>
</div>			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
	<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>