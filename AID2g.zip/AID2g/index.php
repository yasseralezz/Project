<?php
require('config/config5.php'); 
error_reporting(E_ERROR | E_PARSE);

if( !$user->is_logged_in() ){ 
if (!isset($_SESSION["user_id"]) && $_SESSION["user_id"] == "")
	$stop = '<h2> To view products you have<br/> to <a href="login/login.php">Login</a></h2>';
 } 

?>
<!DOCTYPE HTML>
<head>
<title>Home | Obaid Store</title>
<link href="assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="assets/js/jquery-1.11.1.min.js"></script>

<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width">
  <style>

    #slides .slidesjs-previous {
      margin-right: 5px;
      float: left;
    }

    #slides .slidesjs-next {
      margin-right: 5px;
      float: left;
    }

    .slidesjs-pagination {
      margin: 6px 0 0;
      float: right;
      list-style: none;
    }

    .slidesjs-pagination li {
      float: left;
      margin: 0 1px;
    }

    .slidesjs-pagination li a {
      display: block;
      width: 13px;
      height: 0;
      padding-top: 13px;
      background-image: url(assets/images/pagination.png);
      background-position: 0 0;
      float: left;
      overflow: hidden;
    }

    .slidesjs-pagination li a.active,
    .slidesjs-pagination li a:hover.active {
      background-position: 0 -13px
    }

    .slidesjs-pagination li a:hover {
      background-position: 0 -26px
    }

    #slides a:link,
    #slides a:visited {
      color: #333
    }

    #slides a:hover,
    #slides a:active {
      color: #9e2020
    }

    .navbar {
      overflow: hidden
    }

    #slides {
      display: none
    }

    .container {
      margin: 0 auto
    }

    /* For tablets & smart phones */
    @media (max-width: 767px) {
      body {
        padding-left: 20px;
        padding-right: 20px;
      }
      .container {
        width: auto
      }
    }

    /* For smartphones */
    @media (max-width: 480px) {
      .container {
        width: auto
      }
    }

    /* For smaller displays like laptops */
    @media (min-width: 768px) and (max-width: 979px) {
      .container {
        width: 900px
      }
    }

    /* For larger displays */
    @media (min-width: 1200px) {
      .container {
        width: 900px
      }
    }
  </style>
</head>
<body>
<?php
	require 'header.php';
	require 'topnev.php';
	require 'leftnev.php';
	require 'footer.php';
	require 'product/displayshop.php';

	session_start();

?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev(); ?>

		<div class="header_bottom">
			<div class="slider-text">
				<?php header1(); ?>
			</div>

			<div class="container">
				<div id="slides">
					<img src="assets/images/slide-1.png" alt="Gaming PC Console"/>
      					<img src="assets/images/slide-2.png" alt="Gaming PC Console"/>
      					<img src="assets/images/slide-3.png" alt="Gaming PC Console"/>
      					<img src="assets/images/slide-4.png" alt="Gaming PC Console"/>
     					<a href="#" class="slidesjs-previous slidesjs-navigation"><i class="icon-chevron-left icon-large"></i></a>
     					<a href="#" class="slidesjs-next slidesjs-navigation"><i class="icon-chevron-right icon-large"></i></a>
     				</div>
			</div>		

  <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
  <script src="assets/js/jquery.slides.min.js"></script>

  <script>
    $(function() {
      $('#slides').slidesjs({
        width: 940,
        height: 720,
        navigation: false
      });
    });
  </script>
			</div><div class="clear"></div>
		</div>
	</div>
</div>


<div class="main">
	<div class="content">
		<div class="content_bottom">
			<div class="wrap">
				<div class="content-bottom-left">
				<div class="googleSearch">
					<div class="categories">
						<h3> Google Custom Search </h3>
<form method="get" id="searchform" id="searchbox_000732843338151667528:dpdnr_pwwrs" action="API_login/google/search-result.html">

<input value="000732843338151667528:dpdnr_pwwrs" name="cx" type="hidden"/>
<input value="FORID:11" name="cof" type="hidden"/>
<input type="text" value="" placeholder="What are you looking for?" name="s" id="s" onfocus="defaultInput(this)" onblur="clearInput(this)" />
<input type="submit" id="searchsubmit" value="Search" />

</form></div><br/><br/><br/><br/>
					</div>	
					<div class="categories">
						<?php	leftnev1();	?>
					</div>		
					<div class="buters-guide">
						<?php	leftnev2();	?>
					</div>

				</div>
 
    	    	<div class="content-bottom-right">
    	    	<h3>Products</h3>
	            <div class="section group"> 
					<?php 
						if(isset($stop)){

					echo "<h4>$stop</h4>";

				} else { ?>
					<?php			
						require 'classes/functions.php';
						$cart = new shoppingCart();
						$database = new Database_connect();
						$sql = 'SELECT * FROM products order by name ASC';
						$result = mysql_query($sql);
						$output[] = ' ';
						while ($user_data = mysql_fetch_array($result)){
 
											}
									$output[] = ' ';
									echo join ('',$output);
									ShowProduct();
									

									?>
									<?php } ?>

                
                 </div>
				</div>
				<br/>
               <br/>
		      </div>
		      <div class="clear"></div>
		   </div>
         </div>
      </div>
    </div>
	
	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev();	?>
		    </div>		
        </div>
	</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>