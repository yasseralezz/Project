<?php
$page = '../index.php';
//include "../config/config4.php";

$connection=mysqli_connect('localhost', 'yasyus3_obaid', 'yasser123', 'yasyus3_obaid') or die('Failed to connect');


function ShowProduct() {
	$get = mysqli_query($GLOBALS['connection'], 'SELECT productID, name, price, imageName, quantity FROM products ORDER BY ProductID DESC');
	if (mysqli_num_rows($get) == 0) {
		echo 'Could not find DataBase';
	} else {
		while ($get_row = mysqli_fetch_assoc($get)) {
			echo '<div class="grid_1_of_4 images_1_of_4"> <h4>'.$get_row['name'].'</h4>';
			echo '<img src="product/images/' . $get_row['imageName'].'"  width="400" height="200" '; 
			echo 'alt="'. $get_row['name'].'" />';
			echo '<p>$'.$get_row['price'].'</p>';
			echo '<div class="add-cart"><h4><a href="product/cart.php?action=add&productID='.$get_row['productID'].'">Add To Cart</a></h4>';
			echo '</div><div class="clear"></div></div>';
		}
		
	}

}

?>