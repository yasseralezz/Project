<?php
require '../config/config.php'; 
require '../classes/functions.php';

session_start();

if(!isset($_SESSION['username']))if(!isset($_SESSION['user_id'])) {header('Location: login/login.php'); }
 

$cart_class = new shoppingCart();
$cart = $_SESSION['cart'];
$action = $_GET['action'];
switch($action){
	case 'add';
	if ($cart){
		$cart .= ','.$_GET['productID'];
	}else {
		$cart = $_GET['productID'];
	}
	break;
	case'delete';
     if ($cart){
		$items = explode(',',$cart);
		$newcart = '';
		foreach($items as $item){
			if($_GET['productID'] !=$item){
				if($newcart != ''){
					$newcart .= ','.$item;
				} else {
					$newcart= $item;
				}
			}
		}
		$cart = $newcart;
}
break;
case 'update';
if($cart){
		$newcart = '';
		foreach($_POST as $key=>$value){
			if(stristr($key,'quantity')){
				$id = str_replace('quantity','',$key);
				$items = ($newcart !='') ? explode(',',$newcart) : explode(',',$cart);
				$newcart = '';
				foreach ($items as $item){
					if($id !=$item){
						if($newcart !=''){
							$newcart.=','.$item;
						}else{
							$newcart = $item;
						}
					}
				}
				for ($i=1;$i<=$value;$i++){
					if($newcart !=''){
						$newcart .= ','.$id;
					}else{
						$newcart = $id;
					}
				}
			}
		}
	}
	$cart = $newcart;
	break;
	
}
$_SESSION['cart'] = $cart;
?>
<!DOCTYPE HTML>
<head>
<title> Your cart | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev2(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Your cart </li>
						<div class="clear"> </div>
				</ul>

				<div class="product-details">	
					<div class="contact-form">
						<div class="contact">
							<div class="tablestyle">
								<table style="width:100%">
									<tbody>
										<tr>
											<th>Product Image</th>
											<th>Product Name</th>		
											<th>Price</th>
											<th>Quantity</th>
											<th>Total</th>
											<th> &nbsp;</th>
										</tr>
										<?php 
											//echo $cart_class->writeShoppingCart();
											echo $cart_class->showCart();
										?>
									
							</div>
							<div class="clear"></div>
						</div>
					</div> 
				</div>
			</div>
		</div>
	</div>
</div>	


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
	<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>