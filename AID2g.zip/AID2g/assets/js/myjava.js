$(function(){
	
	$('#bs-prod').on('keyup',function(){
		var search_data = $('#bs-prod').val();
		var url = 'search.php';
		$.ajax({
		type:'POST',
		url:url,
		data:'search_data='+search_data,
		success: function(datos){
			$('#agrega-registros').html(datos);
		}
	});
	return false;
	});
});

