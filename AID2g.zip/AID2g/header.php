<?php
	function logo() {
	echo '<div class="logo">
	<a href="index.php"><img src="assets/images/logo.png" width="500" height="70" alt="Logo" /></a>
	</div><br/>
	<div class="header_top_right">
	<div class="search_box">';
	
if (!isset($_SESSION["username"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome back ';
	echo $_SESSION['username'];
	echo ' | <a href="login/profile.php">Profile</a> | <a href="login/logout.php">Logout</a></h2></div><br/>';
	}
	
//google login	
	if (!isset($_SESSION["name"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome back ';
	echo $_SESSION['name'];
	echo ' | <a href="API_login/google/logout.php">Logout</a></h2></div><br/>';
	}	
	
if (!isset($_SESSION["admin_name"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome boss! | <a href="admin/admin_logout.php">Logout</a></h2></div>';
	}
	
	
	echo '<div class="clear"></div>';
	} 	

	
	
	function header1() {
		echo '<h2>OBAID STORE<br/></h2>
		<p>We have the cheapest and latest gaming PC parts!</p>
		<a href="aboutus.php">Read more About us!</a>';
	} 

	
	function header_product_image() {
		echo '<img src="assets/images/header.png" alt="Awesome stuff" />';
	}		

?>

<?php
//login folder

	function logo2() {
	echo '<div class="logo">
	<a href="../index.php"><img src="../assets/images/logo.png" width="500" height="70" alt="Logo" /></a>
	</div><br/>
	<div class="header_top_right">
	<div class="search_box">';
	
if (!isset($_SESSION["username"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome back ';
	echo $_SESSION['username'];
	echo ' | <a href="logout.php">Logout</a></h2></div><br/>';
	}
	
//google login	
	if (!isset($_SESSION["name"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome back ';
	echo $_SESSION['name'];
	echo ' | <a href="logout.php">Logout</a></h2></div><br/>';
	}
	
if (!isset($_SESSION["admin_name"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome boss! | <a href="admin_logout.php">Logout</a></h2></div>';
	}
	
	echo '<div class="clear"></div>';
	} 
?>

<?php
//other folders

	function logo3() {
	echo '<div class="logo">
	<a href="../index.php"><img src="../assets/images/logo.png" width="500" height="70" alt="Logo" /></a>
	</div><br/>
	<div class="header_top_right">
	<div class="search_box">';
	
if (!isset($_SESSION["username"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome back ';
	echo $_SESSION['username'];
	echo ' | <a href="../login/profile.php">Profile</a> | <a href="../login/logout.php">Logout</a></h2></div><br/>';
	}
	
//google login	
	if (!isset($_SESSION["name"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome back ';
	echo $_SESSION['name'];
	echo ' | <a href="../login/logout.php">Logout</a><br/></h2></div><br/>';
	}	
	
if (!isset($_SESSION["admin_name"])) {
	} else {
	echo '<div class="userstyle"><h2>Welcome boss! | <a href="../admin/admin_logout.php">Logout</a></h2></div>';
	}
	
	echo '<div class="clear"></div>';
	} 
?>