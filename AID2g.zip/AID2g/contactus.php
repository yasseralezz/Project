<!DOCTYPE HTML>
<head>
<title>Contact Us | Obaid Store</title>
<link href="assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<link href="contactus/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="contactus/api.js" type="text/javascript"></script>
<script type="text/javascript" src="assets/js/jquery-1.11.1.min.js"></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>

</head>
<body>
<?php
	require 'header.php';
	require 'topnev.php';
	require 'footer.php';
	session_start();
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev(); ?>

<div class="clear"></div>
		</div>
	</div>
</div>

<div class="main_bg">
	<div class="Contactwrap">
		<div class="main">
			<div class="contact">				
					<div class="contact_left">
						<div class="contact_info">
							<h3>Find Us Here</h3>
								<div class="map">
								<div id="googleMap" style="width: 400px; height: 300px;"></div>
								</div>
						</div>
						<div class="company_address">
							<h3>Company Information :</h3>
							<div id="msg"> </div>
						</div>
					</div>
					
					<div class="contact_right">
						<div class="contact-form">
							<h3>Contact Us</h3>
							<div class="nbutton">
								<div id="page-wrapper">
								  <div id="form-messages"></div>
									<form id="ajax-contact" method="post" action="contactus/mailer.php">
										<div class="field">
											<label for="name">Name:</label>
											<input type="text" id="name" name="name" required>
										</div>

										<div class="field">
											<label for="email">Email:</label>
											<input type="email" id="email" name="email" required>
										</div>

										<div class="field">
											<label for="message">Message:</label>
											<textarea id="message" name="message" required></textarea>
										</div>

										<div class="field">
											<button type="submit">Send</button>
										</div>
									</form>
								</div>
								<script src="contactus/jquery-2.1.0.min.js"></script>
								<script src="contactus/app.js"></script>
							</div>
						</div>
					</div>
			</div><div class="clear"></div>				
		</div>
	</div>
</div>     
<div class="footer">
	<div class="wrap">	
		<div class="copy_right">
			<?php	copyright();	?>
		</div>	
		<div class="footer-nav">
			<?php	footernev();	?>
		</div>		
	</div>
</div>
<script type="text/javascript">
var myCenter=new google.maps.LatLng(41.159455,-81.4276);
var marker;

function initialize()
{
var mapProp = {
  center:myCenter,
  zoom:12,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };

    var locations = [
      ['Obaid Store', 41.159455, -81.4276],
    ];


var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

var marker=new google.maps.Marker({
  position:myCenter,
  animation:google.maps.Animation.BOUNCE
  });
  
  var infowindow = new google.maps.InfoWindow({
  content:"Obaid Store"
  });
  
  infowindow.open(map,marker);

// Zoom to 9 when clicking on marker
google.maps.event.addListener(marker,'click',function() {
  map.setZoom(17);
  map.setCenter(marker.getPosition());
  });


marker.setMap(map);
}



google.maps.event.addDomListener(window, 'load', initialize);
</script>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script type="text/javascript">
 
$(document).ready(function(){
var url="contactus/JSON&jQuery.php";
$.getJSON(url,function(json){
// loop thrcoough the members here
$.each(json.members,function(i,dat){
$("#msg").append(
'<p>'+
''+dat.text+''+
'</p>'
);
});
});
});
 
</script>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>