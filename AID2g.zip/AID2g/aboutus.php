<!DOCTYPE HTML>
<head>
<title>About Us | Obaid Store</title>
<link href="assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require 'header.php';
	require 'topnev.php';
	require 'footer.php';
	session_start();
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev(); ?>

<div class="clear"></div>
		</div>
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<div class="cont-desc span_1_of_2">
					<ul class="back-links">
						<li> About Us </li>
						<div class="clear"> </div>
					</ul>
					<div class="product-details">
						<?php 
							include 'config/config4!.php';
							
							$row=$db->prepare('select * from JSONaboutus');

							$row->execute();//execute the query
							$json_data=array();//create the array
							foreach($row as $rec)//foreach loop
							{
								$json_array['id']=$rec['id'];
								$json_array['text']=$rec['text'];
								
								echo '<h2>'.$json_array['text'].'</h2>';
								echo '<br/><br/>';
																
							//here pushing the values in to an array
								array_push($json_data,$json_array);

							}

							//built in PHP function to encode the data in to JSON format
								//echo json_encode($json_data);
						?>								
						<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>   
 
<div class="footer">
	<div class="wrap">	
		<div class="copy_right">
			<?php	copyright();	?>
		</div>	
		<div class="footer-nav">
			<?php	footernev();	?>
		</div>		
	</div>
</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>