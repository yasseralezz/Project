<!DOCTYPE HTML>
<head>
<title>XML | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
	session_start();
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Using XML </li>
						<div class="clear"> </div>
				</ul>

					<div class="product-details">	
						<div class="contact-form">
							<center><h2> <a href="XMLfromDB.php"><input type="submit" value="Item Desc"></a> | <a href="XML&XSL.php"><input type="submit" value="View prices"></a> </h2>
						</div>
					<div class="clear"></div>
				</div>			
			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>	
</body>
</html>