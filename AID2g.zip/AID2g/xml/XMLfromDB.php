<!DOCTYPE HTML>
<head>
<title>XML | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
	session_start();
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Using XML </li>
						<div class="clear"> </div>
				</ul>

					<div class="product-details">	
						<?php	
							
							$connection = mysqli_connect('localhost', 'yasyus3_obaid', 'yasser123', 'yasyus3_obaid') or die(mysqli_error());
							
							$result=mysqli_query($connection, "SELECT * FROM xmltable") or die (mysqli_error());
							
							$_xml = '<?xml version="1.0" encoding="UTF-8" ?>';
							$_xml .="<xmltable>";
							
							while ($row = mysqli_fetch_assoc($result)) {
								$_xml .="<xmltable>";
								$_xml .="<id>".$row['id']."</id>";
								$_xml .="<company>".$row['company']."</company>";
								$_xml .="<model>".$row['model']."</model>";
								$_xml .="<itemdesc>".$row['itemdesc']."</itemdesc>";
								$_xml .="</xmltable>";
							}
							$_xml .="</xmltable>";
							$xmlobj = new SimpleXMLElement($_xml);
							
							
							$xsl = new DOMDocument;
							$xsl->load('fetch_from_db.xsl');

							$proc = new XSLTProcessor;
							
							$proc->importStyleSheet($xsl);
							
							echo $proc->transformToXML ($xmlobj);
							//$xmlobj->asXML('fetch_from_db.xml');
						?>	
						 <div class="contact-form">
							<h2> <a href="index.php"><input type="submit" value="Back"></a> </h2>
						</div>
					<div class="clear"></div>
				</div>			
			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>