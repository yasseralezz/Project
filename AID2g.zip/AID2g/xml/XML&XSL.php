<!DOCTYPE HTML>
<head>

<script>
function loadXMLDoc(filename) 
{
if (window.ActiveXObject)
{
	xhttp = new ActiveXObject ("Msxm12.XMLHTTP");
}
else
{
xhttp = new XMLHttpRequest ();
}
xhttp.open("GET", filename, false);
try {xhttp.responseType = "msxml-decument"} catch(err) {} 
xhttp.send("");
return xhttp.responseXML;
}

function displayResult()
{
	
xml = loadXMLDoc ("XML&XSL.xml");
xsl = loadXMLDoc ("XML&XSL.xsl");

if (window.ActiveXObject || xhttp.responseType == "msxml-document")
{
ex = xml.transformNode(xsl);
document.getElementById("display").innerHTML = ex;
}

else if (document.implementation && document.implementation.createDocument)
{ 

xsltProcessor = new XSLTProcessor();
xsltProcessor.importStylesheet(xsl);
resultDocument = xsltProcessor.transformToFragment (xml, document);
document.getElementById("display").appendChild(resultDocument);

}
}
</script>
<title>XML | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body onload="displayResult()">
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
	session_start();
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Using XML </li>
						<div class="clear"> </div>
				</ul>

					<div class="product-details">	
						<div id="display"></div>
						 <div class="contact-form">
							<h2> <a href="index.php"><input type="submit" value="Back"></a> </h2>
						</div>
					<div class="clear"></div>
				</div>			
			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>