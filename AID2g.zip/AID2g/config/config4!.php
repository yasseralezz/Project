<?php
error_reporting( E_ALL & ~E_DEPRECATED & ~E_NOTICE );
ob_start();
session_start();
//change the database name
define('DB_DRIVER', 'mysql');
define('DBHOST', 'localhost');
define('DBUSER', 'yasyus3_obaid');
define('DBPASS', 'yasser123');
define('DBNAME', 'yasyus3_obaid');


define('PROJECT_NAME', 'obaid Store');
$dboptions = array(
              PDO::ATTR_PERSISTENT => FALSE, 
              PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, 
              PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
              PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
            );

try {
  $db = new PDO(DB_DRIVER.':host='.DBHOST.';dbname='.DBNAME, DBUSER, DBPASS , $dboptions);  
} catch (Exception $ex) {
  echo $ex->getMessage();
  die;
}

//get error/success messages
if ($_SESSION["errorType"] != "" && $_SESSION["errorMsg"] != "" ) {
    $ERROR_TYPE = $_SESSION["errorType"];
    $ERROR_MSG = $_SESSION["errorMsg"];
    $_SESSION["errorType"] = "";
    $_SESSION["errorMsg"] = "";
}


?>