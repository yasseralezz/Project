<?php
error_reporting( E_ALL & ~E_DEPRECATED & ~E_NOTICE );
ob_start();
session_start();

//set timezone
date_default_timezone_set("Asia/Kuala_Lumpur");

//change the database name
define('DBHOST','localhost');
define('DBUSER','yasyus3_obaid');
define('DBPASS','yasser123');
define('DBNAME','yasyus3_obaid');

//application address
define('DIR','http://yasseralezz.com/AID/');
define('SITEEMAIL','info@yasseralezz.com');

try {

	//create PDO connection 
	$db = new PDO("mysql:host=".DBHOST.";port=;dbname=".DBNAME, DBUSER, DBPASS);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch(PDOException $e) {
	//show error
    echo '<p class="bg-danger">'.$e->getMessage().'</p>';
    exit;
}

if ($_SESSION["errorType"] != "" && $_SESSION["errorMsg"] != "" ) {
    $ERROR_TYPE = $_SESSION["errorType"];
    $ERROR_MSG = $_SESSION["errorMsg"];
    $_SESSION["errorType"] = "";
    $_SESSION["errorMsg"] = "";
}
//include the user class, pass in the database connection
include('classes/user.php');
$user = new User($db); 

?>