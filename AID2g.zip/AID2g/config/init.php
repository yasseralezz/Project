<?php
	include "../includes/functions/datetime.php";
	
	//echo "AAA";
?>