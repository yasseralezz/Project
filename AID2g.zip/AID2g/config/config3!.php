<?php
error_reporting(0);
//change the database name
define('DBHOST', 'localhost');
define('DBUSER', 'yasyus3_obaid');
define('DBPASS', 'yasser123');
define('DBNAME', 'yasyus3_obaid');
?>