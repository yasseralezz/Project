<?php
	//change the Database Name 
	class Connection {
		public static function getConnection() {
			$connection = mysqli_connect('localhost', 'yasyus3_obaid', 'yasser123', 'yasyus3_obaid') or die(mysqli_error());
			
			return $connection;
		}
	}
	//change the database name
	$connect = mysql_connect('localhost', 'yasyus3_obaid', 'yasser123');
	mysql_select_db('yasyus3_obaid', $connect);
?>