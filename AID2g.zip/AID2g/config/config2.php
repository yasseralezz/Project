<?php
$config['base_url']='http://yasseralezz/AID';
//change the database name
$db['hostname'] = 'localhost';
$db['username'] = 'yasyus3_obaid';
$db['password'] = 'yasser123';
$db['database'] = 'yasyus3_obaid';
$db['dbdriver'] = 'mysql';
?>