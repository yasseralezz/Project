<?php
	session_start();
	require_once("../classes/common_functions.php");
	unset($_SESSION["admin_name"]);
	session_destroy();
	redirect("../index.php");
?>