<?php
require('../fpdf/fpdf.php');

include '../config/connection.php';

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../fpdf/recursos/tienda.gif' , 10 ,8, 10 , 13,'GIF');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'PRODUCT DETAILS', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Date: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LIST OF PRODUCTS', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'Item', 0);
$pdf->Cell(80, 8, 'Name', 0);
$pdf->Cell(40, 8, 'Price', 0);
$pdf->Cell(25, 8, 'P. quantity', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$result = mysql_query("SELECT * FROM products");
$item = 0;
$totaluni = 0;
$totaldis = 0;
while($row = mysql_fetch_array($result)){
	$item = $item+1;
	$totaluni = $totaluni + $row['price'];
	$totaldis = $totaldis + $row['quantity'];
	$pdf->Cell(15, 8, $item, 0);
	$pdf->Cell(80, 8,$row['name'], 0);
	$pdf->Cell(40, 8, $row['price'], 0);
	$pdf->Cell(25, 8, 'S/. '.$row['quantity'], 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Cell(31,8,'Total price: S/. '.$totaluni,0);
$pdf->Cell(32,8,'Total quantity: S/. '.$totaldis,0);
$pdf->Output();
?>