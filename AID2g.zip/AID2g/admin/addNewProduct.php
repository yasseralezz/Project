<?php
require '../config/config.php';
require_once("../classes/common_functions.php");

session_start();

if (!$_SESSION["admin_name"]) redirect("adminpage1.php");

//define page title
$title = 'Manage products';
?>
<!DOCTYPE HTML>
<head>
<title> Add new product | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Add new product</li>
						<div class="clear"> </div>
				</ul>

<div class="product-details">	
		<div class="contact-form">
<form method="post" action="WriteProduct.php"  enctype="multipart/form-data">
				<fieldset class="fieldset-width1">
					<table>
					<tr><td><label class="align" for="txtProductName">Product Name: </label></td>
					<td><input type="text" name="txtProductName"  /></td></tr>
					<tr><td><label class="align"for="txtProductPrice">Price: </label></td>
					<td><input type="text" name="txtProductPrice"  /></tr>
					<tr><td><label class="align"for="txtQuantity">Quantity: </label></td>
					<td><input type="text" name="txtQuantity"  /></tr>
					<tr><td><label class="align" for="txtProductImage">Image Filename: </label></td>
					<td><input type="file" name="fileToUpload" id="fileToUpload"></td></tr>
					</table><br/>
					<input type="submit" value="Add" name='submit' />
					
				</fieldset>
			</form>
			<a href="adminpage2.php"><input type="submit" value="Back"></a>
	</div>
<div class="clear"></div>
</div>			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>