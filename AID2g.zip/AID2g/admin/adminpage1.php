<?php
require_once '../config/config.php';
require_once("../classes/common_functions.php");

if (!$_SESSION["admin_name"]) redirect("adminlogin.php");


if (!(isset($_GET['pagenum']))) {
  $pagenum = 1;
} else {
  $pagenum = $_GET['pagenum'];
}
$page_limit = ($_GET["show"] <> "" && is_numeric($_GET["show"]) ) ? $_GET["show"] : 8;


try {
  $keyword = trim($_GET["keyword"]);
  if ($keyword <> "" ) {
    $sql = "SELECT * FROM PCparts WHERE 1 AND "
            . " (motherboard LIKE :keyword) ORDER BY motherboard ";
    $stmt = $db->prepare($sql);
    
    $stmt->bindValue(":keyword", $keyword."%");
    
  } else {
    $sql = "SELECT * FROM PCparts WHERE 1 ORDER BY motherboard ";
    $stmt = $db->prepare($sql);
  }
  
  $stmt->execute();
  $total_count = count($stmt->fetchAll());

  $last = ceil($total_count / $page_limit);

  
  
  if ($keyword <> "" ) {
    $stmt->bindValue(":keyword", $keyword."%");
   }
   
  $stmt->execute();
  $results = $stmt->fetchAll();
} catch (Exception $ex) {
  echo $ex->getMessage();
}
/*******PAGINATION CODE ENDS*****************/
?>
<!DOCTYPE HTML>
<head>
<title>Admin index | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script src="../assets/js/html5shiv.js"></script>
<script src="../assets/js/respond.min.js"></script>
<script src="../assets/js/jquery-1.9.0.min.js"></script>
<script src="../assets/js/myjava.js"></script>
<script type="text/javascript" src="assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
					<ul class="back-links">
						<li>Admin page</li>
						<div class="clear"> </div>
					</ul>
					<div class="product-details">
						<div class="contact-form">
						<div class="contact">	
							<div class="desc span_3_of_2">						
					

								
						<form action="adminpage1.php" method="get" >
							<label class="col-lg-12 control-label" for="keyword">
							<input type="text" value="<?php echo $_GET["keyword"]; ?>" name="keyword" id="" class="form-control" placeholder="Motherboards type only">
							
							</label>
							
<input type="submit" name="submit" value="Search">

				<?php if ($ERROR_MSG <> "") { ?>
					<div class="alert alert-dismissable alert-<?php echo $ERROR_TYPE ?>">
								<br/><h3><?php echo $ERROR_MSG; } ?></h3>
						</div>
						</form>
						
						<?php if (count($results) > 0) { ?>
							</div>
        <div class="tablestyle">
          <table>
            <tbody><tr>
                <th>System picture</th>
                <th>Motherboard</th>
                <th>Processor</th>
                <th>Video card</th>
                <th>Power supply</th>
                <th>&nbsp;</th>

              </tr>
  <?php foreach ($results as $res) { ?>
                <tr>
                  <td style="text-align: center;">
                <?php $pic = ($res["image"] <> "" ) ? $res["image"] : "no_avatar.png" ?>
                    <a href="../assets/images/PCparts/<?php echo $pic ?>" target="_blank"><img src="../assets/images/PCparts/<?php echo $pic ?>" alt="" width="50" height="50" ></a>
                  </td>
                  <td><?php echo $res["motherboard"]; ?></td>
                  <td><?php echo $res["processor"]; ?></td>
                  <td><?php echo $res["vcard"]; ?></td>
                  <td><?php echo $res["power"]; ?></td>
                  <td>
                    <a href="manageData.php?m=update&sysid=<?php echo $res["sys_id"]; ?>&pagenum=<?php echo $_GET["pagenum"]; ?>"><input type="button" value="Edit"></a>&nbsp;
                    <a href="process_form.php?mode=delete&sysid=<?php echo $res["sys_id"]; ?>&keyword=<?php echo $_GET["keyword"]; ?>&pagenum=<?php echo $_GET["pagenum"]; ?>" onclick="return confirm('Are you sure?')"><input type="button" value="Delete"></a>&nbsp;
                  </td>
                </tr>
  <?php } ?>
            </tbody></table>

        </div><a href="manageData.php"><input type="submit" value="Add new data"></a>


          <?php } else { ?>
        <div class="well well-lg">No Data found.</div>
<?php } ?>
						</div>
						</div>
						<div class="clear"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>   
 
<div class="footer">
	<div class="wrap">	
		<div class="copy_right">
			<?php	copyright();	?>
		</div>	
		<div class="footer-nav">
			<?php	footernev2();	?>
		</div>		
	</div>
</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>