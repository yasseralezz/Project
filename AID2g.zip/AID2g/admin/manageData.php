<?php
require '../config/config.php';
try {
   $sql = "SELECT * FROM PCparts WHERE 1 AND sys_id = :sysid";
   $stmt = $db->prepare($sql);
   $stmt->bindValue(":sysid", intval($_GET["sysid"]));
   
   $stmt->execute();
   $results = $stmt->fetchAll();
} catch (Exception $ex) {
  echo $ex->getMessage();
}
?>

<!DOCTYPE HTML>
<head>
<title> Add | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

<script src="../assets/js/respond.min.js"></script>
<script src="../assets/js/jquery-1.9.0.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
					<ul class="back-links">
						<li> <h3 class="panel-title"><?php echo ($_GET["m"] == "update") ? "Edit" : "Add"; ?> new data</h3> </li>
						<div class="clear"> </div>
					</ul>
					<div class="product-details">
						<div class="contact-form">
								<div class="desc span_3_of_2">						
          
        <form class="form-horizontal" name="contact_form" id="contact_form" enctype="multipart/form-data" method="post" action="process_form.php">
          <input type="hidden" name="mode" value="<?php echo ($_GET["m"] == "update") ? "update_old" : "add_new"; ?>" >
          <input type="hidden" name="old_pic" value="<?php echo $results[0]["image"] ?>" >
          <input type="hidden" name="sysid" value="<?php echo intval($results[0]["sys_id"]); ?>" >
          <fieldset>
            <div class="form-group">
              <label class="col-lg-4 control-label" for="motherbaordval"><span class="required"></span>Motherbaord type:</label>
              <div class="col-lg-5">
                <input type="text" value="<?php echo $results[0]["motherboard"] ?>" placeholder="Motherbaord" id="motherbaordval" class="form-control" name="motherboard"><span id="motherbaordval_err" class="error"></span>
              </div>
            </div><br/>
            
            <div class="form-group">
              <label class="col-lg-4 control-label" for="vcardval">Video (GPU) card type:</label>
              <div class="col-lg-5">
                <input type="text" value="<?php echo $results[0]["vcard"] ?>" placeholder="Video card" id="vcardval" class="form-control" name="vcard"><span id="vcardval_err" class="error"></span>
              </div>
            </div><br/>
            
            <div class="form-group">
              <label class="col-lg-4 control-label" for="processorval"><span class="required"></span>Processor (CPU) type:</label>
              <div class="col-lg-5">
                <input type="text" value="<?php echo $results[0]["processor"] ?>" placeholder="Processor" id="processorval" class="form-control" name="processor"><span id="processorval_err" class="error"></span>
              </div>
            </div><br/>
            
            
            <div class="form-group">
              <label class="col-lg-4 control-label" for="powerval"><span class="required"></span>Power supply type:</label>
              <div class="col-lg-5">
                <input type="text" value="<?php echo $results[0]["power"] ?>" placeholder="Power supply" id="powerval" class="form-control" name="power"><span id="powerval_err" class="error"></span>
              </div>
            </div><br/>
            

            <div class="form-group">
              <label class="col-lg-4 control-label" for="image">Profile picture:</label>
              <div class="col-lg-5">
                <input type="file"  id="image" class="form-control file" name="image"><span id="image_err" class="error"></span>
                <span class="help-block">Only jpg, jpeg, png and gif images</span>
              </div>
            </div>
            
            <?php if ($_GET["m"] == "update") { ?>
            <div class="form-group">
              <div class="col-lg-1 col-lg-offset-4">
                <?php $pic = ($results[0]["image"] <> "" ) ? $results[0]["image"] : "no_avatar.png" ?>
                <a href="../assets/images/PCparts/<?php echo $pic ?>" target="_blank"><img src="../assets/images/PCparts/<?php echo $pic ?>" alt="" width="100" height="100" class="thumbnail" ></a>
              </div>
            </div>
            <?php 
            }
            ?>

            
            <div class="form-group">
              <div class="col-lg-5 col-lg-offset-4">
				<input type="submit" name="submit" value="Update">
              </div>
            </div>
          </fieldset>
        </form>

      </div>
    </div>
  </div>

<script type="text/javascript">
$(document).ready(function() {
	
	// the fade out effect on hover
	$('.error').hover(function() {
		$(this).fadeOut(200);  
	});
	
	
	$("#contact_form").submit(function() {
		$('.error').fadeOut(200);  
		if(!validateForm()) {
            // go to the top of form first
            $(window).scrollTop($("#contact_form").offset().top);
			return false;
		}     
		return true;
    });

});

function validateForm() {
	 var errCnt = 0;
	 
	var motherbaordval = $.trim( $("#motherbaordval").val());
	var processorval = $.trim( $("#processorval").val());
	var powerval = $.trim( $("#powerval").val());
	var vcardval = $.trim( $("#vcardval").val());

	 var image =  $.trim( $("#image").val());

	
	if (motherbaordval == "" ) {
		$("#motherbaordval_err").html("Please do not leave it blank.");
		$('#motherbaordval_err').fadeIn("fast"); 
		errCnt++;
	}  else if (motherbaordval.length <= 2 ) {
		$("#motherbaordval_err").html("Enter atleast 3 letter.");
		$('#motherbaordval_err').fadeIn("fast"); 
		errCnt++;
	}
    

        
   
    if (powerval == "" ) {
		$("#powerval_err").html("Please do not leave it blank.");
		$('#powerval_err').fadeIn("fast"); 
		errCnt++;
	}  else if (powerval.length <= 2 ) {
		$("#powerval_err").html("Enter atleast 3 letter.");
		$('#powerval_err').fadeIn("fast"); 
		errCnt++;
	}
            
      
    if (vcardval == "" ) {
		$("#vcardval_err").html("Please do not leave it blank.");
		$('#vcardval_err').fadeIn("fast"); 
		errCnt++;
	}  else if (vcardval.length <= 2 ) {
		$("#vcardval_err").html("Enter atleast 3 letter.");
		$('#vcardval_err').fadeIn("fast"); 
		errCnt++;
	}
            
   
    if (processorval == "" ) {
		$("#processorval_err").html("Please do not leave it blank.");
		$('#processorval_err').fadeIn("fast"); 
		errCnt++;
	}  else if (processorval.length <= 2 ) {
		$("#processorval_err").html("Enter atleast 3 letter.");
		$('#processorval_err').fadeIn("fast"); 
		errCnt++;
	}
    

    
    
    if (image.length > 0) {
        var exts = ['jpg','jpeg','png','gif', 'bmp'];
		var get_ext = image.split('.');
		get_ext = get_ext.reverse();
        
       
        if ($.inArray ( get_ext[0].toLowerCase(), exts ) <= -1 ){
          $("#image_err").html("Must me jpg, jpeg, png, gif, bmp image only..");
          $('#image_err').fadeIn("fast"); 
        }
       
    }
    
	if(errCnt > 0) return false; else return true;
}
 
</script>
						</div>

						
						<div class="clear"></div>
					
				</div>
			</div>
		</div>
	</div>
</div>   
 
<div class="footer">
	<div class="wrap">	
		<div class="copy_right">
			<?php	copyright();	?>
		</div>	
		<div class="footer-nav">
			<?php	footernev2();	?>
		</div>		
	</div>
</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>