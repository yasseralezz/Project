<?php
require '../config/config.php';
$mode = $_REQUEST["mode"];
if ($mode == "add_new" ) {
  $motherboard = trim($_POST['motherboard']);
  $processor = trim($_POST['processor']);
  $vcard = trim($_POST['vcard']);
  $power = trim($_POST['power']);
  $filename = "";
  $error = FALSE;

  if (is_uploaded_file($_FILES["image"]["tmp_name"])) {
    $filename = time() . '_' . $_FILES["image"]["name"];
    $filepath = '../assets/images/PCparts/' . $filename;
    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $filepath)) {
      $error = TRUE;
    }
  }

  if (!$error) {
    $sql = "INSERT INTO `PCparts` (`motherboard`, `processor`, `vcard`, `power`, `image`) VALUES "
            . "( :motherboard, :processor, :power, :vcard, :pic)";

    try {
      $stmt = $db->prepare($sql);

      // bind the values
      $stmt->bindValue(":motherboard", $motherboard);
      $stmt->bindValue(":processor", $processor);
      $stmt->bindValue(":power", $power);
      $stmt->bindValue(":vcard", $vcard);
      $stmt->bindValue(":pic", $filename);

      // execute Query
      $stmt->execute();
      $result = $stmt->rowCount();
      if ($result > 0) {
        $_SESSION["errorType"] = "success";
        $_SESSION["errorMsg"] = "Contact added successfully.";
      } else {
        $_SESSION["errorType"] = "danger";
        $_SESSION["errorMsg"] = "Failed to add contact.";
      }
    } catch (Exception $ex) {

      $_SESSION["errorType"] = "danger";
      $_SESSION["errorMsg"] = $ex->getMessage();
    }
  } else {
    $_SESSION["errorType"] = "danger";
    $_SESSION["errorMsg"] = "failed to upload image.";
  }
  header("location: adminpage1.php");
} elseif ( $mode == "update_old" ) {
  
  $motherboard = trim($_POST['motherboard']);
  $processor = trim($_POST['processor']);
  $vcard = trim($_POST['vcard']);
  $power = trim($_POST['power']);
  $sysid = trim($_POST['sysid']);
  $filename = "";
  $error = FALSE;

  if (is_uploaded_file($_FILES["image"]["tmp_name"])) {
    $filename = time() . '_' . $_FILES["image"]["name"];
    $filepath = '../assets/images/PCparts/' . $filename;
    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $filepath)) {
      $error = TRUE;
    }
  } else {
     $filename = $_POST['old_pic'];
  }

  if (!$error) {
    $sql = "UPDATE `PCparts` SET `motherboard` = :motherboard, `processor` = :processor, `power` = :power, `vcard` = :vcard, `image` = :pic  "
            . "WHERE sys_id = :sysid ";

    try {
      $stmt = $db->prepare($sql);

      // bind the values
      $stmt->bindValue(":motherboard", $motherboard);
      $stmt->bindValue(":processor", $processor);
      $stmt->bindValue(":power", $power);
      $stmt->bindValue(":vcard", $vcard);
      $stmt->bindValue(":pic", $filename);
      $stmt->bindValue(":sysid", $sysid);

      // execute Query
      $stmt->execute();
      $result = $stmt->rowCount();
      if ($result > 0) {
        $_SESSION["errorType"] = "success";
        $_SESSION["errorMsg"] = "Data updated successfully.";
      } else {
        $_SESSION["errorType"] = "info";
        $_SESSION["errorMsg"] = "No data has been changed.";
      }
    } catch (Exception $ex) {

      $_SESSION["errorType"] = "danger";
      $_SESSION["errorMsg"] = $ex->getMessage();
    }
  } else {
    $_SESSION["errorType"] = "danger";
    $_SESSION["errorMsg"] = "Failed to upload image.";
  }
  header("location:adminpage1.php");
} elseif ( $mode == "delete" ) {
   $sysid = intval($_GET['sysid']);
   
   $sql = "DELETE FROM `PCparts` WHERE sys_id = :sysid";
   try {
     
      $stmt = $db->prepare($sql);
      $stmt->bindValue(":sysid", $sysid);
        
       $stmt->execute();  
       $res = $stmt->rowCount();
       if ($res > 0) {
        $_SESSION["errorType"] = "success";
        $_SESSION["errorMsg"] = "Data deleted successfully.";
      } else {
        $_SESSION["errorType"] = "info";
        $_SESSION["errorMsg"] = "Failed to delete data.";
      }
     
   } catch (Exception $ex) {
      $_SESSION["errorType"] = "danger";
      $_SESSION["errorMsg"] = $ex->getMessage();
   }
   
   header("location:adminpage1.php");
}
?>