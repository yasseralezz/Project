<?php
	$page = 'index.php';
	
	function leftnev1() {
		echo '<ul>	<h3>OOTesting</h3>';
		echo '<li><a href="OOtest/ooProductTest.php">Products</a></li>';	
		echo '<li><a href="OOtest/ooUserTest.php">Users</a></li>';
		echo '<li><a href="OOtest/testObjectCollection.php">Object Collection</a></li>';	
		echo '</ul><br/><br/>';
	}		

	
	function leftnev2() {
		echo '<h3>Why us?</h3>
			<p><span>We want you to be happy with your purchase.</span></p>	
			<p>So we\'re committed to giving you all the tools to make the right decision with minimum fuss. </p>';
	}		
	
	
?>