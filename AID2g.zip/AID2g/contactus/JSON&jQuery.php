<?php

$link = mysql_pconnect("localhost", "yasyus3_obaid", "yasser123") or die("Could not connect");
mysql_select_db("yasyus3_obaid") or die("Could not select database");
 
$arr = array();
 
$rs = mysql_query("SELECT * FROM companyInfo");
 
while($obj = mysql_fetch_object($rs)) {
$arr[] = $obj;
}
echo '{"members":'.json_encode($arr).'}';

?>