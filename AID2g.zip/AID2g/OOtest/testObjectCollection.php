<?php
	include "../config/config2.php";
	include "../classes/ObjectCollection.php";
	include "../classes/LineItem.php";
	include "../classes/Item.php";
	
	session_start();
	$result = "";
	$mysqli_conn = new mysqli ($db['hostname'], $db ['username'], 
							$db['password'], $db ['database']);
	
	$result =$mysqli_conn ->query ("SELECT * FROM item");
	if($mysqli_conn -> connect_errno) {
    print "Faild to connect to MySQL: (" . 
	$mysqli_conn -> connect_errno . ")" . $mysqli_conn -> connect_error;
	}
	
?>
<!DOCTYPE HTML>
<head>
<title> OO Product test | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo3(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Object Collection</li>
						<div class="clear"> </div>
				</ul>

<div class="product-details">	
		<div class="contact-form">

<?php
//displaying the product
	$counter=1;
		while($row = $result->fetch_assoc()) {
			print '<a href="displayPage.php?id='.$row["id"].'"><input type="submit" value="item '.$counter.' "> </a> ';
			print " ".$row["description"]." <br/>";


			$counter++;
		}
		
		
?>
<?php 
			//session part to display customer order
			$ca = new ObjectCollection();
			$bb = new Item("12",12);
			$aa = new LineItem($bb,10);
			
			if(isset($_SESSION["ObjColl"]))
			{
				$ca = $_SESSION["ObjColl"];
				$aa = $ca->getLineItem(0);
				echo "<br/><br/>Times Ordered: <br/>".$ca->getLineCount();
				
				for($i=0;$i<$ca->getLineCount();$i++)
				{
					echo "<br/>Product Description: ".$ca->getLineItem($i)->getItem()->getDescription();
					echo "<br/>Product Price: ".$ca->getLineItem($i)->getItem()->getPrice();
					echo "<br/>Quantity Ordered: ".$ca->getLineItem($i)->getQuantity();
					echo "<br/>";	
				}
				
			}
			
?> 

		<br/><br/><a href="../index.php"><input type="submit" value="Back"></a></div>


	</div>
<div class="clear"></div>
</div>			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
	<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>