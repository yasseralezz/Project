<?php
	include "../config/config2.php";
	include "../classes/ObjectCollection.php";
	include "../classes/LineItem.php";
	include "../classes/Item.php";
	
	session_start();
	$result = "";
	$mysqli_conn = new mysqli ($db['hostname'], $db ['username'], 
							$db['password'], $db ['database']);
	
	$result =$mysqli_conn ->query ("SELECT * FROM item");
	if($mysqli_conn -> connect_errno) {
    print "Faild to connect to MySQL: (" . 
	$mysqli_conn -> connect_errno . ")" . $mysqli_conn -> connect_error;
	}
	
?>
<!DOCTYPE HTML>
<head>
<title> OO Product test | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev2(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Object Collection</li>
						<div class="clear"> </div>
				</ul>
<div class="desc span_3_of_2">
<div class="product-details">	
		<div class="contact-form">
 <?php

	include "../config/config2.php";
	
	$result = "";
	$mysqli_conn = new mysqli ($db['hostname'], $db ['username'], 
							$db['password'], $db ['database']);

	if ($_SERVER ["REQUEST_METHOD"] == "GET") {
		$id = $_GET["id"];
		
		$result =$mysqli_conn ->query ("SELECT * FROM item
		WHERE id = '".$id."'");
		
		$counter=1;
		while ($row = $result->fetch_assoc()) {
 			print '<p> Product ID: '.$row["id"].'</p>';
			print '<p> Description: '.$row["description"].'</p>';
			print '<p> Image: '.$row["image"].'</p>';
			print '<p> Price: '.$row["price"].'</p>';
			
		}
	}
	
	?>
<form id="myForm" method="post" action="../classes/addToCollection.php">
	<br/>Quantity:
	<input type="text" name="txtQuantity" required>
	<input type="submit" name="submit" value="Add">
	<input type="hidden" name="txtId" value="<?=$_GET["id"]; ?>">
	</form> 
		  <a href="../OOtest/testObjectCollection.php"><input type="submit" value="Cancle"></a></div>


	</div></div>
<div class="clear"></div>
</div>			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
	<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>