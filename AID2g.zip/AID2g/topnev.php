<?php
	function topnev() {
		echo '<nav><div class="menuStyle"><ul id="menu" class="clearfix">';
		echo '<li><a href="index.php">Home</a></li>';
		echo '<li><a href="#">About Us</a> <ul><li class="green"><a href="aboutus.php">History</a></li></ul></li>';
		echo '<li><a href="#">Contact Us</a> <ul><li class="red"><a href="contactus.php">Find us</a></li></ul></li>';
		//if user is not logged in 
			if(!isset($_SESSION['username']))if(!isset($_SESSION['user_id'])) {
				echo '<li><a href="#">Sign in</a><ul><li class="blue"><a href="login/login.php">Login</a></li>';
				echo '<li class="purple"><a href="login/register.php">Register</a></li></ul></li>';
			}
		//if user is logged in
			if(isset($_SESSION['username'])) {
				echo '<li><a href="#">Profile</a><ul><li class="purple"><a href="login/profile.php">Settings</a></li></ul></li>';	
			}	
		//if admin not logged in	
			if(!isset($_SESSION['admin_name'])) {
			echo '<li><a href="#">Admin page</a><ul><li class="gold"><a href="admin/adminlogin.php">Login</a></li></ul></li>';
			}	
		//if admin logged in	
			if(isset($_SESSION['admin_name'])) {
			echo '<li><a href="#">Admin Settings</a><ul><li class="blue"><a href="admin/adminpage1.php">Manage PC systems</a></li>';
			echo '<li class="purple"><a href="admin/adminpage2.php">Manage Products</a></li></ul></li>';
			}
		echo '<li><a href="#">API</a> 
			<ul><li class="green"><a href="weather/index.html">Check Weather</a></li>
			<li class="red"><a href="Geolocation/index.html">Geolocation</a></li>
			<li class="blue"><a href="facebook/index.php">Facebook feeds</a></li>
			</ul></li>';	
		echo '<li><a href="xml/index.php">xml</a></li>';
		echo '<li><a href="angular/index.php">Angular</a></li>';
		echo '</ul></div></nav>';
	} 
	
//back from the login folder
	function topnev2() {
		echo '<nav><div class="menuStyle"><ul id="menu" class="clearfix">';
		echo '<li><a href="../index.php">Home</a></li>';
		echo '<li><a href="#">About Us</a> <ul><li class="green"><a href="../aboutus.php">History</a></li></ul></li>';
		echo '<li><a href="#">Contact Us</a> <ul><li class="red"><a href="../contactus.php">Find us</a></li></ul></li>';
		//if user is not logged in 
			if(!isset($_SESSION['username']))if(!isset($_SESSION['user_id'])) {
				echo '<li><a href="#">Sign in</a><ul><li class="blue"><a href="login.php">Login</a></li>';
				echo '<li class="purple"><a href="register.php">Register</a></li></ul></li>';
			}
		//if user is logged in
			if(isset($_SESSION['username'])) {
				echo '<li><a href="#">Profile</a><ul><li class="purple"><a href="profile.php">Settings</a></li></ul></li>';	
			}	
		//if admin not logged in	
			if(!isset($_SESSION['admin_name'])) {
			echo '<li><a href="#">Admin page</a><ul><li class="gold"><a href="../admin/adminlogin.php">Login</a></li></ul></li>';
			}	
		//if admin logged in	
			if(isset($_SESSION['admin_name'])) {
			echo '<li><a href="#">Admin Settings</a><ul><li class="blue"><a href="../admin/adminpage1.php">Manage PC systems</a></li>';
			echo '<li class="purple"><a href="../admin/adminpage2.php">Manage Products</a></li></ul></li>';
			}
		echo '<li><a href="#">API</a> 
			<ul><li class="green"><a href="../weather/index.html">Check Weather</a></li>
			<li class="red"><a href="../Geolocation/index.html">Geolocation</a></li>
			<li class="blue"><a href="../facebook/index.php">Facebook feeds</a></li>
			</ul></li>';	
		echo '<li><a href="../xml/index.php">xml</a></li>';
		echo '<li><a href="../angular/index.php">Angular</a></li>';
		echo '</ul></div></nav>';
	} 	

// back from the folders
	function topnev3() {
		echo '<nav><div class="menuStyle"><ul id="menu" class="clearfix">';
		echo '<li><a href="../index.php">Home</a></li>';
		echo '<li><a href="#">About Us</a> <ul><li class="green"><a href="../aboutus.php">History</a></li></ul></li>';
		echo '<li><a href="#">Contact Us</a> <ul><li class="red"><a href="../contactus.php">Find us</a></li></ul></li>';
		//if user is not logged in 
			if(!isset($_SESSION['username']))if(!isset($_SESSION['user_id'])) {
				echo '<li><a href="#">Sign in</a><ul><li class="blue"><a href="../login/login.php">Login</a></li>';
				echo '<li class="purple"><a href="../register.php">Register</a></li></ul></li>';
			}
		//if user is logged in
			if(isset($_SESSION['username'])) {
				echo '<li><a href="#">Profile</a><ul><li class="purple"><a href="../login/profile.php">Settings</a></li></ul></li>';	
			}	
		//if admin not logged in	
			if(!isset($_SESSION['admin_name'])) {
			echo '<li><a href="#">Admin page</a><ul><li class="gold"><a href="../admin/adminlogin.php">Login</a></li></ul></li>';
			}	
		//if admin logged in	
			if(isset($_SESSION['admin_name'])) {
			echo '<li><a href="#">Admin Settings</a><ul><li class="blue"><a href="../admin/adminpage1.php">Manage PC systems</a></li>';
			echo '<li class="purple"><a href="../admin/adminpage2.php">Manage Products</a></li></ul></li>';
			}
		echo '<li><a href="#">API</a> 
			<ul><li class="green"><a href="../weather/index.html">Check Weather</a></li>
			<li class="red"><a href="../Geolocation/index.html">Geolocation</a></li>
			<li class="blue"><a href="../facebook/index.php">Facebook feeds</a></li>
			</ul></li>';	
		echo '<li><a href="../xml/index.php">xml</a></li>';
		echo '<li><a href="../angular/index.php">Angular</a></li>';
		echo '</ul></div></nav>';
	} 
?>