<?php
//include config
require_once('../config/config.php');

//check if already logged in move to home page
if( $user->is_logged_in() ){ header('Location: error.php'); } 

//process login form if submitted
if(isset($_POST['submit'])){

	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if($user->login($username,$password)){ 
		$_SESSION['username'] = $username;
		header('Location: profile.php');
		exit;
	
	} else {
		$error[] = 'Wrong username or password or your account has not been activated.';
	}

}//end if submit

//if user logged in from google
if (isset($_SESSION["name"]) && $_SESSION["name1"] == "") {
  // user already logged in the site
header('Location: error.php');
}

//define page title
$title = 'Login';
?>
<!DOCTYPE HTML>
<head>
<title>Login | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>
</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
	session_start();
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev2(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Login </li>
						<div class="clear"> </div>
				</ul>

<div class="product-details">	
	<div class="desc span_3_of_2">
		<h2>Login to your account</h2><br/>
		<div class="login_left">
		<div class="contact-form">
			<form role="form" method="post" action="" autocomplete="off">
					<?php
				//check for any errors
				if(isset($error)){
					foreach($error as $error){
						echo '<h1>'.$error.'</h1>';
					}
				}

				if(isset($_GET['action'])){

					//check the action
					switch ($_GET['action']) {
						case 'active':
							echo "<h1>Your account is now active you may now log in.</h1>";
							break;
						case 'reset':
							echo "<h1>Please check your inbox for a reset link.</h1>";
							break;
						case 'resetAccount':
							echo "<h1>Password changed, you may now login.</h1>";
							break;
					}

				}

				
				?>
				<input type="text" name="username" id="username" placeholder="UserName" value="<?php if(isset($error)){ echo $_POST['username']; } ?>" tabindex="1" required>
				<input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" tabindex="3" required>
				<input type="submit" value="Login" name="submit"  tabindex="5">
			</form>
			<br/><p> Do not have an account? <a href="register.php">Register</a> now!<br/>
			Forget your password? <a href='reset.php'>Click here!</a></p>	
		</div></div>
	</div>
				<div class="or_fixed">
			<h2 class="or">OR</h2></div>
			<div class="login_right"><br/><br/><br/><br/> <?php echo $_SESSION['name']; ?>
			
			<a href="../API_login/google/google_login.php"><img src="../assets/images/google.png" width="300" height="50" alt="Login with google" /></a>
</div></div>			
<div class="clear"></div>
</div>			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
	<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>