<?php require('../config/config.php'); 
session_start();

//if form has been submitted process it
if(isset($_POST['submit'])){

	//email validation
	if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
	    $error[] = 'Please enter a valid email address';
	} else {
		$stmt = $db->prepare('SELECT email FROM members WHERE email = :email');
		$stmt->execute(array(':email' => $_POST['email']));
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		if(empty($row['email'])){
			$error[] = 'Email provided is not recognised.';
		}
			
	}

	//if no errors have been created carry on
	if(!isset($error)){

		//create the activasion code
		$token = md5(uniqid(rand(),true));

		try {

			$stmt = $db->prepare("UPDATE members SET resetToken = :token, resetComplete='No' WHERE email = :email");
			$stmt->execute(array(
				':email' => $row['email'],
				':token' => $token
			));

			//send email
			$to = $row['email'];
			$subject = "Password Reset";
			$body = "Dear user,\n\n Reset password has been requested. \n\n".DIR."login/resetPassword.php?key=$token\n\nPlease remember, your reset link is only valid once.\n\nAll the best!\n\nRegards yasseralezz.";
			$additionalheaders = "From: <".SITEEMAIL.">\r\n";
			$additionalheaders .= "Reply-To: $".SITEEMAIL."";
			mail($to, $subject, $body, $additionalheaders);

			//redirect to index page
			header('Location: login.php?action=reset');
			exit;

		//else catch the exception and show the error.
		} catch(PDOException $e) {
		    $error[] = $e->getMessage();
		}

	}

}

//define page title
$title = 'Reset Account';
?>
<!DOCTYPE HTML>
<head>
<title>Reset your password | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>

</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev2(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Reset your password </li>
						<div class="clear"> </div>
				</ul>

<div class="product-details">	
	<div class="desc span_3_of_2">
		<h1>Reset your password</h1><br/>
		<div class="contact-form">
			<form role="form" method="post" action="" autocomplete="off">
					<?php
				//check for any errors
				if(isset($error)){
					foreach($error as $error){
						echo '<p class="bg-danger">'.$error.'</p>';
					}
				}

				if(isset($_GET['action'])){

					//check the action
					switch ($_GET['action']) {
						case 'active':
							echo "<h2 class='bg-success'>Your account is now active you may now log in.</h2>";
							break;
						case 'reset':
							echo "<h2 class='bg-success'>Please check your inbox for a reset link.</h2>";
							break;
					}
				}
				?>
					<input type="email" name="email" id="email" class="form-control input-lg" placeholder="Your e-mail address" value="" tabindex="1" required>
				<input type="submit" name="submit" value="Reset" class="btn btn-primary btn-block btn-lg" tabindex="2">
			</form>
			<br/><p> Do not have an account? <a href="register.php">Register</a> now!<br/>
			Already have an account? <a href='login.php'>Login!</a></p>	
		</div>
	</div>
<div class="clear"></div>
</div>			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>
</body>
</html>