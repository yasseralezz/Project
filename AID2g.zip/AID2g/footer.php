<?php
	function copyright() {
		echo '<p>Obaid Store Inc. 2016 All rights reserved.</p>';
	}	
	
	
	function footernev() {
		echo '<p><ul>';
		echo '<li><a href="index.php">Home</a> | </li>';
		echo '<li><a href="aboutus.php">About Us</a> | </li>';
		echo '<li><a href="contactus.php">Contact Us</a> | </li>';
		echo '<li><a href="FAQs.html">FAQs</a></li>';
		echo '</ul></p>';
	}	
	
?>
<?php
//login folder
	function copyright2() {
		echo '<p>Obaid Store Inc. 2016 All rights reserved.</p>';
	}	
	
	
	function footernev2() {
		echo '<p><ul>';
		echo '<li><a href="../index.php">Home</a> | </li>';
		echo '<li><a href="../aboutus.php">About Us</a> | </li>';
		echo '<li><a href="../contactus.php">Contact Us</a> | </li>';
		echo '<li><a href="../FAQs.html">FAQs</a></li>';
		echo '</ul></p>';
	}	
	
?>