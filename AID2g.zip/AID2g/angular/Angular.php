<!DOCTYPE HTML>
<head>
<title>Angular | Obaid Store</title>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../assets/css/awesome-fonts.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="../assets/js/jquery-1.11.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.1.5/angular.min.js"></script>
<link href="style.css" rel="stylesheet" type="text/css" media="all"/>
<script>
function TodoCtrl($scope) {
  $scope.todos = [];
  $scope.markAll = false;
    
  $scope.addTodo = function() {
      if(event.keyCode == 13 && $scope.todoText){
          $scope.todos.push({text:$scope.todoText, done:false});
          $scope.todoText = '';
      }
  };
  $scope.isTodo = function(){
      return $scope.todos.length > 0;  
  }
  $scope.toggleEditMode = function(){
      $(event.target).closest('li').toggleClass('editing');
  };
  $scope.editOnEnter = function(todo){
      if(event.keyCode == 13 && todo.text){
          $scope.toggleEditMode();
      }
  };
    
  $scope.remaining = function() {
    var count = 0;
    angular.forEach($scope.todos, function(todo) {
      count += todo.done ? 0 : 1;
    });
    return count;
  };

  $scope.hasDone = function() {
      return ($scope.todos.length != $scope.remaining());
  }    
    
  $scope.itemText = function() {
      return ($scope.todos.length - $scope.remaining() > 1) ? "items" : "item";     
  };
      
  $scope.toggleMarkAll = function() {
      angular.forEach($scope.todos, function(todo) {
        todo.done =$scope.markAll;
      });
  };
  
  $scope.clear = function() {
    var oldTodos = $scope.todos;
    $scope.todos = [];
    angular.forEach(oldTodos, function(todo) {
      if (!todo.done) $scope.todos.push(todo);
    });
  };
    
}
</script>
</head>
<body>
<?php
	require '../header.php';
	require '../topnev.php';
	require '../footer.php';
	session_start();
?>
	<div class="header">
  	  		<div class="wrap">
				<div class="header_top">
					<?php logo2(); ?>
		     	</div>
			</div>
		<div class="clear"></div>
	</div>  
	<?php topnev3(); ?>
	
	</div>
</div>

<div class="main">
	<div class="wrap">
		<div class="preview-page">
			<div class="section group">
				<ul class="back-links">
					<li> Using Angular </li>
						<div class="clear"> </div>
				</ul>

					<div class="product-details">	

<div ng-app>
  <div id="todoapp" ng-controller="TodoCtrl">
    <header>
        <h1>Todo list with Angular</h1>
        <input id="new-todo" type="text" ng-model="todoText"  size="30"
        placeholder="What needs to be done?" ng-keyup="addTodo()"/>
    </header>

    <section id="main" style="display: block;">
        <div ng-show="isTodo()">
          <input id="toggle-all" type="checkbox" ng-model="markAll"
            ng-click="toggleMarkAll()"/>
          <label for="toggle-all">Mark all as complete</label>
        </div>
        
        <ul id="todo-list" class="unstyled">
          <li ng-repeat="todo in todos" ng-dblclick="toggleEditMode()">
            <div class="view" ng-keyup="editTodo()">
              <input type="checkbox" ng-model="todo.done"/>
              <span class="done-{{todo.done}}" >{{todo.text}}</span>
            </div>
            <input class="edit" type="text" ng-model="todo.text"
              ng-keyup="editOnEnter(todo)"/>
          </li>
        </ul>
    </section>
    
    <footer style="display: block;">
        <div class="todo-count">{{remaining()}} of {{todos.length}} remaining</div>
          <a id="clear-completed" ng-click="clear()" ng-show="hasDone()">
              Clear <span >{{(todos.length - remaining())}} {{itemText()}}</span>.
          </a>
    </footer>
          
  </div>
</div>
<div class="contact-form">
							<h2> <a href="index.php"><input type="submit" value="Back"></a></h2>
						</div>
					<div class="clear"></div>
				</div>			
			</div> 
		</div>
	</div>
</div>


	<div class="footer">
		<div class="wrap">	
			<div class="copy_right">
				<?php	copyright2();	?>
			</div>	
			<div class="footer-nav">
				<?php	footernev2();	?>
		    </div>		
        </div>
	</div>
<script type="text/javascript">
$(function(){
  $('a[href="#"]').on('click', function(e){
    e.preventDefault();
  });
  
  $('#menu > li').on('mouseover', function(e){
    $(this).find("ul:first").show();
    $(this).find('> a').addClass('active');
  }).on('mouseout', function(e){
    $(this).find("ul:first").hide();
    $(this).find('> a').removeClass('active');
  });
  
  $('#menu li li').on('mouseover',function(e){
    if($(this).has('ul').length) {
      $(this).parent().addClass('expanded');
    }
    $('ul:first',this).parent().find('> a').addClass('active');
    $('ul:first',this).show();
  }).on('mouseout',function(e){
    $(this).parent().removeClass('expanded');
    $('ul:first',this).parent().find('> a').removeClass('active');
    $('ul:first', this).hide();
  });
});
</script>	
</body>
</html>