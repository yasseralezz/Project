<?php 
$DB_HOST = 'localhost';
$DB_USER = 'yasyus3_obaid';
$DB_PASS = 'yasser123';
$DB_NAME = 'yasyus3_obaid';
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
?>